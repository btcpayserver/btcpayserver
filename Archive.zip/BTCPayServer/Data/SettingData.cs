﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BTCPayServer.Data
{
    public class SettingData
    {
        public string Id
        {
            get; set;
        }

        public string Value
        {
            get; set;
        }
    }
}
